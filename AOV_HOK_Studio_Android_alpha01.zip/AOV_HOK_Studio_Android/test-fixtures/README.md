Do not commit large game AssetBundles into this repository by default.

Use the Lixin AssetBundle supplied in this conversation as a local test file. Its fingerprint is recorded in `lixin_fixture_manifest.json`. Open the bundle from the APK's file picker when testing inventory, TypeTree, PPtr, texture/mesh export and numeric TypeTree write-back.
