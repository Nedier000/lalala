# Implementation status (Alpha 0.1)

| Capability | Current state | Evidence / limitation |
|---|---|---|
| Android standalone UI | Implemented in Kotlin | File picker, inventory, object actions |
| UnityPy_AOV core integration | Source integrated | Chaquopy packages still need a successful CI build and device smoke test |
| Object inventory | Implemented | Loads environment and reports object metadata |
| TypeTree view | Implemented | Generic TypeTree, subject to parser/type-tree availability |
| PPtr trace | Implemented | Traces pointers in one selected TypeTree; external file refs unresolved unless loaded in same env |
| Raw export | Implemented | Exports the selected object's serialized bytes |
| Mesh OBJ export | Implemented | Uses bundled Mesh exporter |
| Texture PNG preview/export | Attempted through UnityPy converter | ASTC/ETC/PVRTC decoders are not yet packaged for Android |
| Numeric TypeTree edit | Implemented with guard + read-back | Existing numeric value only; not specialized ParticleSystem editor |
| AssetBundle save | Implemented through `Environment.save` | Must be exercised in CI/on device with Lixin file |
| Material inspector | Generic TypeTree only | Does not execute Unity shader |
| 3D preview | Not implemented | Future OpenGL ES / bundled viewer work |
| Particle preview/simulation | Not implemented | Need full module data and runtime-compatible renderer |
| AoV ZSTD + dictionary | Reference files present | `pyzstd` not integrated |
| GitHub Actions | Implemented | Build artifact upload configured; workflow has not been run from a user's GitHub repository |
| APK binary | Not built in this environment | No Android SDK/Gradle install and container has no outbound DNS/network access |

## No false success claims

The CI workflow must pass and a real APK artifact must exist before calling the APK built. The exported bundle must also be tested on Android and in game before claiming game-side edit success.
