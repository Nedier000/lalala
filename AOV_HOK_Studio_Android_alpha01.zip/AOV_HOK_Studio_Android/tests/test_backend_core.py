import importlib.util
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
BACKEND = os.path.join(ROOT, "app", "src", "main", "python", "aov_android_backend.py")
spec = importlib.util.spec_from_file_location("aov_android_backend", BACKEND)
backend = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backend)


class BackendHelpersTest(unittest.TestCase):
    def test_get_nested_numeric(self):
        tree = {"m_SavedProperties": {"m_Floats": {"_Cutoff": 0.35}}}
        self.assertAlmostEqual(backend._get_path(tree, "m_SavedProperties.m_Floats._Cutoff"), 0.35)

    def test_set_float_preserves_float_type(self):
        tree = {"startSize": {"scalar": 0.13}}
        old = backend._set_path(tree, "startSize.scalar", 1.17)
        self.assertAlmostEqual(old, 0.13)
        self.assertIsInstance(tree["startSize"]["scalar"], float)
        self.assertAlmostEqual(tree["startSize"]["scalar"], 1.17)

    def test_set_integer_preserves_integer_type(self):
        tree = {"m_Ints": {"_Mode": 2}}
        backend._set_path(tree, "m_Ints._Mode", 3.8)
        self.assertEqual(tree["m_Ints"]["_Mode"], 3)
        self.assertIsInstance(tree["m_Ints"]["_Mode"], int)

    def test_list_index(self):
        tree = {"curve": {"keys": [{"value": 0.2}, {"value": 0.5}]}}
        backend._set_path(tree, "curve.keys[1].value", 0.9)
        self.assertAlmostEqual(backend._get_path(tree, "curve.keys[1].value"), 0.9)

    def test_reject_missing_property(self):
        with self.assertRaises(KeyError):
            backend._set_path({"x": 1.0}, "missing", 2.0)

    def test_reject_boolean(self):
        with self.assertRaises(TypeError):
            backend._set_path({"enabled": True}, "enabled", 0.0)


if __name__ == "__main__":
    unittest.main()
