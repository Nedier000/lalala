# AoV / HOK Studio for Android — Alpha 0.1

Android-first AssetBundle inspection/editor foundation based on the user's AOV_UABE_2022 2.1 source and UnityPy_AOV fork.

## What this alpha does

- Opens a user-selected `.assetbundle` through Android's Storage Access Framework.
- Loads the file using the bundled `AssetbundleUtils.UnityPy_AOV` parser.
- Lists serialized objects with type, PathID, class ID, container path and byte size.
- Shows an object's generic TypeTree.
- Lists PPtr references embedded in a TypeTree.
- Exports raw serialized object data.
- Exports a Mesh as OBJ.
- Attempts Texture2D/Sprite PNG preview and export using the available UnityPy texture decoder path.
- Edits an **existing numeric TypeTree field** by explicit property path, writes a new bundle (never overwrites the source), reopens it and verifies the changed value.
- Runs a GitHub Actions workflow to build a debug APK and uploads the APK as an artifact.

## Not yet in this alpha

This is not yet the full requested editor. The following are not implemented/verified yet:

- Full in-app OBJ/SkinnedMesh 3D viewport.
- Runtime-equivalent Unity shader rendering. A material's serialized properties can be inspected in TypeTree; that does not run the game's shader.
- ParticleSystem timeline simulation. ParticleSystem and ParticleSystemRenderer can be inspected through the TypeTree when the bundle has usable TypeTree data; a reliable particle simulator is not included.
- Specialized visual controls for Particle startSize/size-over-lifetime, leaf tint/alpha, emission and glow. The current generic numeric editor can edit an existing numeric field only after the user knows its exact TypeTree path.
- Texture import/re-encode for all ASTC, ETC, PVRTC and Crunch formats. The native decoders/encoders from the desktop requirements need Android ABI-compatible builds. Unsupported formats must report an error, not silently convert to RGBA32.
- Full AoV Zstandard/DATABIN dictionary workflow. The supplied dictionary is included as a reference asset, but `pyzstd` is not wired into the Android engine yet.
- External `.resS`/`.resource` rebasing and full multi-bundle project management.

The alpha therefore contains real AssetBundle read, inspection, raw/OBJ export and guarded TypeTree numeric edit paths, but not all promised visual-editing features. Do not treat material preview as the exact in-game shader result.

## Source basis

- `AOV_UABE_2022-latest.zip` from the user's `update.zip` (folder version 2.1): `AssetbundleUtils/UnityPy_AOV`, `ReferenceGraph.py`, `EffectPipeline.py`, `TextureImport.py`, `MeshImport.py`, `AnimationPipeline.py`, preview/export helpers and project modules.
- `hi.zip`: additional AOV UnityPy and effect/texture/mesh logic used as supporting reference.
- `AOV_HOK_particle_leaf_glow_edit_logic.json`: edit rules for particle size, leaf texture/tint/alpha and glow/material tracing.
- `AoV_Zstd.py` and `zstd_dict.bin`: retained as reference material; only the dictionary is bundled in app assets at this stage.

The desktop Tkinter/OpenGL application entrypoint is deliberately not imported into Android. The APK uses a Kotlin Activity for UI and the UnityPy_AOV core via Chaquopy.

## Build using GitHub Actions

1. Create an empty GitHub repository (public or private).
2. Upload the **contents** of this folder to the repository root (not the parent folder).
3. Commit to `main` or `master`.
4. Open **Actions → Build AoV HOK Studio APK → Run workflow**. A push to `main`/`master` also triggers the workflow.
5. When the workflow succeeds, open its run, scroll to **Artifacts**, and download `AOV-HOK-Studio-debug-apk`.
6. Extract `app-debug.apk` and install it on the Android phone. Allow installation from that file manager if Android prompts.

The workflow currently uses:
- JDK 17
- Gradle 8.13
- Android SDK platform 36 / Build Tools 36.0.0
- Chaquopy 17.2.0 with Python 3.13
- Android ABIs `arm64-v8a` and `x86_64`

Chaquopy requires minSdk 24. The Android Gradle plugin and Chaquopy plugin versions are pinned in `build.gradle.kts`.

## App workflow

1. Tap **MỞ ASSETBUNDLE** and select a bundle.
2. Wait for inventory parsing. Search by object type, name/container or PathID.
3. Tap an object to view TypeTree, trace PPtr references, edit an existing numeric field, export raw, export texture or export Mesh OBJ where applicable.
4. For an edit, enter a valid TypeTree property path and numeric value. Examples of property paths depend on the selected object's actual tree; do not copy an example path blindly.
5. The backend writes a new AssetBundle in app-private storage, reloads it and verifies the edited value, then asks Android where to save the output.

The source file is copied into the app cache for the session. Original files are not overwritten.

## Lixin test fixture

`test-fixtures/lixin_fixture_manifest.json` records the SHA-256 and size of the Lixin AssetBundle supplied for testing. The 55 MB game asset itself is intentionally **not embedded** in the APK or this source archive. Keep a local copy and select it from inside the app.

The file supplied under the name `595_lixin_show_base.assetbundle` has SHA-256:

`ed39fdedd909eda6cd7d473f16989655e933ee90b6a0722221298ef8ea6a5619`

It matches the prior `...particles_9x_correct_weapon_glow_v6` output byte-for-byte in this workspace; it is therefore treated as the user's known-good Lixin test sample, not as an independently verified pristine original.

## Troubleshooting

- **Gradle dependency error:** open the workflow log and find the first `Could not find` / `No matching distributions` line. Chaquopy can only package native Python dependencies for which an Android-compatible wheel exists. The current required packages are `lz4`, `brotli`, `Pillow`, `sm4`, and `pycryptodome`.
- **`ModuleNotFoundError`:** confirm the pip package was installed into the app using the Chaquopy block in `app/build.gradle.kts`.
- **Bundle parse/decryption error:** preserve the exact input and log. Do not resave or patch the source file to get past the error.
- **Texture preview error:** the texture may use a compression format whose Android decoder is not yet packaged. The app should report this rather than showing a false preview.
- **PPtr is unresolved:** it may refer to another CAB/bundle file. This alpha does not fully manage external multi-bundle projects yet.

## Local checks

```bash
python -m compileall -q app/src/main/python
python -m unittest discover -s tests -v
```

Then build with Android Studio or the GitHub Actions workflow.

## Important validation boundary

A successful parser load or bundle read-back only proves structural parsing. It does not prove that the game renders the result correctly. Game validation still requires installing the exported bundle in the correct resource path and testing in the target AoV/HOK build.
