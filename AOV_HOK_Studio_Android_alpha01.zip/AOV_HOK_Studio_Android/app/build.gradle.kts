plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.aov.studio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aov.studio"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-alpha1"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}

chaquopy {
    defaultConfig {
        version = "3.13"
        pip {
            // Core compression/crypto/image dependencies used by UnityPy_AOV.
            // If a package has no Android wheel, CI logs will identify it explicitly.
            install("lz4")
            install("brotli")
            install("Pillow")
            install("sm4==1.0.2")
            install("pycryptodome==3.21.0")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
}
