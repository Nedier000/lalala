"""Android-facing API for the AOV/HOK Studio APK.

This module deliberately imports only the AssetBundle core. Desktop Tk/OpenGL
modules from AOV_UABE are not imported into Android.
"""
from __future__ import annotations

import json
import os
import re
import traceback
from collections import Counter
from pathlib import Path
from typing import Any



def _safe(value: Any, depth: int = 0, max_depth: int = 8):
    if depth > max_depth:
        return "<max-depth>"
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, bytes):
        return {"kind": "bytes", "length": len(value)}
    if isinstance(value, dict):
        return {str(k): _safe(v, depth + 1, max_depth) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(v, depth + 1, max_depth) for v in value[:500]]
    if hasattr(value, "path_id") and hasattr(value, "file_id"):
        return {"m_FileID": int(value.file_id), "m_PathID": int(value.path_id)}
    if hasattr(value, "__dict__"):
        return _safe(vars(value), depth + 1, max_depth)
    return str(value)


def _load(path: str):
    if not path or not os.path.isfile(path):
        raise FileNotFoundError(f"Không tìm thấy file: {path}")
    from AssetbundleUtils import UnityPy_AOV
    return UnityPy_AOV.load(path)


def _object_name(obj, container_names: dict[int, str]) -> str:
    value = container_names.get(int(obj.path_id), "")
    if value:
        return value
    try:
        name = obj.peek_name(default="")
        if name:
            return str(name)
    except Exception:
        pass
    return ""


def inspect_bundle(path: str) -> str:
    """Load a Unity/AoV bundle and return an object inventory as JSON."""
    try:
        env = _load(path)
        objects = list(env.objects)
        counts = Counter()
        container_names: dict[int, str] = {}
        try:
            for container_path, obj in env.container.items():
                container_names[int(obj.path_id)] = str(container_path)
        except Exception:
            pass

        entries = []
        for obj in objects:
            type_name = str(getattr(getattr(obj, "type", None), "name", "Unknown"))
            counts[type_name] += 1
            entries.append({
                "path_id": int(obj.path_id),
                "type": type_name,
                "class_id": int(getattr(obj, "class_id", -1)),
                "name": _object_name(obj, container_names),
                "container": container_names.get(int(obj.path_id), ""),
                "byte_size": int(getattr(obj, "byte_size", 0)),
            })

        files = []
        for key, value in getattr(env, "files", {}).items():
            files.append({"name": str(key), "kind": type(value).__name__,
                          "changed": bool(getattr(value, "is_changed", False))})

        head = b""
        with open(path, "rb") as stream:
            head = stream.read(64)
        signature = head.split(b"\0", 1)[0].decode("ascii", "replace")
        return json.dumps({
            "ok": True,
            "path": os.path.basename(path),
            "size_bytes": os.path.getsize(path),
            "signature": signature,
            "object_count": len(objects),
            "type_counts": dict(sorted(counts.items())),
            "files": files,
            "objects": entries,
            "capabilities": {
                "object_inventory": True,
                "typetree_inspection": True,
                "texture_preview": True,
                "generic_numeric_typetree_edit": True,
                "unity_shader_runtime_preview": False,
                "particle_runtime_simulation": False,
            },
        }, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=12)}, ensure_ascii=False)


def _find_object(env, path_id: int):
    for obj in env.objects:
        if int(obj.path_id) == int(path_id):
            return obj
    raise KeyError(f"Không tìm thấy PathID {path_id}")


def inspect_object(path: str, path_id: int) -> str:
    """Return generic TypeTree for a selected object."""
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        tree = obj.read_typetree()
        serialized = json.dumps(_safe(tree), ensure_ascii=False, indent=2)
        truncated = len(serialized) > 60000
        if truncated:
            serialized = serialized[:60000] + "\n...<truncated>"
        return json.dumps({"ok": True, "path_id": int(path_id),
                           "type": obj.type.name, "class_id": int(obj.class_id),
                           "tree": serialized, "truncated": truncated}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=10)}, ensure_ascii=False)



def export_mesh_obj(path: str, path_id: int, output_obj: str) -> str:
    """Export a Unity Mesh to OBJ using the bundled UnityPy_AOV exporter."""
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        if str(obj.type.name) != "Mesh":
            raise TypeError(f"Object {path_id} không phải Mesh")
        mesh = obj.read()
        text = mesh.export()
        if not text or not isinstance(text, str):
            raise RuntimeError("Mesh exporter không trả về nội dung OBJ")
        Path(output_obj).parent.mkdir(parents=True, exist_ok=True)
        with open(output_obj, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
        return json.dumps({"ok": True, "output": output_obj,
                           "characters": len(text), "path_id": int(path_id)}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=10)}, ensure_ascii=False)


def object_references(path: str, path_id: int) -> str:
    """List serialized PPtrs in a selected object's TypeTree."""
    def walk(value, field=""):
        if isinstance(value, dict):
            if "m_FileID" in value and "m_PathID" in value:
                if int(value.get("m_PathID", 0)):
                    yield {"field": field, "file_id": int(value.get("m_FileID", 0)),
                           "path_id": int(value.get("m_PathID", 0))}
                return
            for key, child in value.items():
                name = f"{field}.{key}" if field else str(key)
                yield from walk(child, name)
        elif isinstance(value, (list, tuple)):
            for i, child in enumerate(value):
                yield from walk(child, f"{field}[{i}]")
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        tree = obj.read_typetree()
        refs = list(walk(tree))
        by_path = {int(x.path_id): x for x in env.objects}
        for ref in refs:
            target = by_path.get(ref["path_id"]) if ref["file_id"] == 0 else None
            ref["target_type"] = str(target.type.name) if target else "external/unresolved"
            if target:
                ref["target_name"] = _object_name(target, {})
        return json.dumps({"ok": True, "path_id": int(path_id),
                           "reference_count": len(refs), "references": refs}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=10)}, ensure_ascii=False)

def export_texture(path: str, path_id: int, output_png: str) -> str:
    """Export Texture2D/Sprite to PNG using the texture converters installed."""
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        if str(obj.type.name) not in ("Texture2D", "Sprite"):
            raise TypeError(f"Object {path_id} không phải Texture2D/Sprite")
        data = obj.read()
        image = getattr(data, "image", None)
        if image is None:
            raise RuntimeError("Không giải mã được ảnh. Có thể thiếu texture decoder cho định dạng này.")
        Path(output_png).parent.mkdir(parents=True, exist_ok=True)
        image.save(output_png, format="PNG")
        return json.dumps({"ok": True, "output": output_png,
                           "width": int(image.width), "height": int(image.height)}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=10)}, ensure_ascii=False)



def export_raw(path: str, path_id: int, output_file: str) -> str:
    """Export original serialized payload for one object."""
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        raw = obj.get_raw_data()
        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        with open(output_file, "wb") as stream:
            stream.write(raw)
        return json.dumps({"ok": True, "output": output_file,
                           "bytes": len(raw), "path_id": int(path_id)}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=10)}, ensure_ascii=False)

def _get_path(root: Any, path: str):
    current = root
    tokens = re.findall(r"([^.[\]]+)|\[(\d+)\]", path)
    if not tokens:
        raise ValueError("Property path trống hoặc không hợp lệ")
    for key, index in tokens:
        if key:
            if not isinstance(current, dict) or key not in current:
                raise KeyError(f"Không tìm thấy property: {key}")
            current = current[key]
        else:
            if not isinstance(current, list):
                raise TypeError("Index chỉ dùng được cho list")
            current = current[int(index)]
    return current


def _set_path(root: Any, path: str, value: Any):
    tokens = re.findall(r"([^.[\]]+)|\[(\d+)\]", path)
    if not tokens:
        raise ValueError("Property path trống hoặc không hợp lệ")
    current = root
    for key, index in tokens[:-1]:
        current = current[key] if key else current[int(index)]
    key, index = tokens[-1]
    if key:
        if not isinstance(current, dict) or key not in current:
            raise KeyError(f"Không tìm thấy property: {key}")
        old = current[key]
        if isinstance(old, bool) or not isinstance(old, (int, float)):
            raise TypeError("Property đích không phải số")
        current[key] = int(value) if isinstance(old, int) else float(value)
    else:
        old = current[int(index)]
        if isinstance(old, bool) or not isinstance(old, (int, float)):
            raise TypeError("Phần tử đích không phải số")
        current[int(index)] = int(value) if isinstance(old, int) else float(value)
    return old


def edit_numeric_property(path: str, path_id: int, property_path: str,
                          new_value: str, output_dir: str) -> str:
    """Edit an existing numeric TypeTree field and save a new bundle copy.

    This API never overwrites the source. It only updates an existing numeric
    field and then reloads the exported bundle to validate the new value.
    """
    try:
        env = _load(path)
        obj = _find_object(env, int(path_id))
        tree = obj.read_typetree()
        old_value = _get_path(tree, property_path)
        numeric = float(new_value)
        if isinstance(old_value, bool) or not isinstance(old_value, (int, float)):
            raise TypeError("Property đích không phải giá trị số")
        previous = _set_path(tree, property_path, numeric)
        obj.save_typetree(tree)
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        env.out_path = output_dir
        env.save(pack="none")
        output_path = os.path.join(output_dir, os.path.basename(path))
        if not os.path.isfile(output_path):
            raise RuntimeError("Không tìm thấy file đầu ra sau khi lưu")

        # Read-back verification against the exported bundle.
        verify_env = _load(output_path)
        verify_obj = _find_object(verify_env, int(path_id))
        verify_tree = verify_obj.read_typetree()
        actual = _get_path(verify_tree, property_path)
        if isinstance(actual, (int, float)) and abs(float(actual) - numeric) > 1e-6:
            raise RuntimeError(f"Giá trị đọc lại không khớp: {actual} != {numeric}")
        return json.dumps({"ok": True, "input": path, "output": output_path,
                           "path_id": int(path_id), "property_path": property_path,
                           "old_value": previous, "new_value": actual,
                           "validated": True}, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "traceback": traceback.format_exc(limit=12)}, ensure_ascii=False)
