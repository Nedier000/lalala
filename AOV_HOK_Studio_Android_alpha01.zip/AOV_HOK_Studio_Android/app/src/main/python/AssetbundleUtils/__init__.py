"""Android-safe subset of AOV_UABE_2022 AssetBundle utilities."""
