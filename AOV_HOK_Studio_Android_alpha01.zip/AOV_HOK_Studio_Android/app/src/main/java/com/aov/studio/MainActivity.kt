package com.aov.studio

import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.chaquo.python.Python
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var search: EditText
    private lateinit var objectsPanel: LinearLayout
    private lateinit var openButton: Button
    private var bundleFile: File? = null
    private var inventory = JSONArray()
    private var typeCounts = JSONObject()
    private var pendingOutput: File? = null
    private var pendingMime = "application/octet-stream"

    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importBundle(uri)
    }
    private val createDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) exportPending(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        setStatus("Sẵn sàng. Mở một AssetBundle để bắt đầu.")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(Color.rgb(15, 17, 27))
        }
        val title = TextView(this).apply {
            text = "AoV / HOK Studio"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "AssetBundle Editor · Android Alpha"
            textSize = 13f
            setTextColor(Color.rgb(173, 179, 198))
        }
        root.addView(subtitle, marginParams(bottom = 14))

        openButton = button("MỞ ASSETBUNDLE") { openDocument.launch(arrayOf("*/*")) }
        root.addView(openButton, matchParams(bottom = 10))

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(213, 217, 230))
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = rounded(Color.rgb(29, 32, 47), 12)
        }
        root.addView(status, matchParams(bottom = 10))

        count = TextView(this).apply {
            text = "Chưa mở bundle"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        root.addView(count, marginParams(bottom = 8))

        search = EditText(this).apply {
            hint = "Tìm theo tên, loại hoặc PathID…"
            textSize = 14f
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(133, 140, 162))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(29, 32, 47), 10)
            isEnabled = false
        }
        root.addView(search, matchParams(bottom = 10))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        objectsPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(objectsPanel)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "Bản thử nghiệm: đọc bundle · xem TypeTree · xuất Texture · sửa field số đã tồn tại · xuất bundle mới"
            textSize = 11f
            setTextColor(Color.rgb(137, 145, 168))
            setPadding(0, dp(9), 0, 0)
        }
        root.addView(footer)
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderObjects() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun importBundle(uri: Uri) {
        openButton.isEnabled = false
        setStatus("Đang sao chép file vào vùng làm việc…")
        io.execute {
            try {
                val name = queryDisplayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "input.assetbundle" }
                val destDir = File(cacheDir, "bundles").apply { mkdirs() }
                val dest = File(destDir, name)
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Không thể mở file đã chọn" }
                    FileOutputStream(dest).use { output -> input.copyTo(output, 1024 * 1024) }
                }
                runOnUiThread { setStatus("Đang phân tích ${dest.name} (${formatBytes(dest.length())})…") }
                val py = Python.getInstance().getModule("aov_android_backend")
                val response = JSONObject(py.callAttr("inspect_bundle", dest.absolutePath).toString())
                runOnUiThread {
                    openButton.isEnabled = true
                    if (!response.optBoolean("ok")) {
                        setStatus("Không đọc được bundle: ${response.optString("error")}")
                        showLong("Lỗi phân tích", response.optString("traceback", response.optString("error")))
                        return@runOnUiThread
                    }
                    bundleFile = dest
                    inventory = response.optJSONArray("objects") ?: JSONArray()
                    typeCounts = response.optJSONObject("type_counts") ?: JSONObject()
                    search.isEnabled = true
                    count.text = "${response.optInt("object_count")} objects  ·  ${typeCounts.length()} loại  ·  ${formatBytes(dest.length())}"
                    setStatus("Đã đọc ${response.optInt("object_count")} object. Chọn object để xem chi tiết.")
                    renderObjects()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    openButton.isEnabled = true
                    setStatus("Lỗi: ${e.message}")
                    showLong("Không thể mở AssetBundle", e.stackTraceToString())
                }
            }
        }
    }

    private fun renderObjects() {
        if (!::objectsPanel.isInitialized) return
        objectsPanel.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        var shown = 0
        for (i in 0 until inventory.length()) {
            val item = inventory.optJSONObject(i) ?: continue
            val name = item.optString("name")
            val type = item.optString("type")
            val pid = item.optLong("path_id")
            val haystack = "$name $type $pid ${item.optString("container")}".lowercase()
            if (q.isNotEmpty() && !haystack.contains(q)) continue
            val label = if (name.isNotBlank()) name else "${type.ifBlank { "Object" }} · $pid"
            val sub = "${type}  |  PathID $pid  |  ${formatBytes(item.optLong("byte_size"))}"
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = rounded(Color.rgb(27, 30, 45), 12)
                isClickable = true
                isFocusable = true
                setOnClickListener { showObjectMenu(item) }
            }
            val nameView = TextView(this).apply {
                text = label
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                maxLines = 2
            }
            val subView = TextView(this).apply {
                text = sub
                textSize = 11f
                setTextColor(Color.rgb(157, 165, 187))
            }
            card.addView(nameView)
            card.addView(subView)
            objectsPanel.addView(card, matchParams(bottom = 7))
            shown++
            if (shown >= 400) break
        }
        if (shown == 0) {
            val empty = TextView(this).apply {
                text = if (inventory.length() == 0) "Chưa có object." else "Không tìm thấy kết quả."
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(0, dp(30), 0, dp(30))
            }
            objectsPanel.addView(empty)
        } else if (shown >= 400) {
            val note = TextView(this).apply {
                text = "Đang hiển thị tối đa 400 kết quả. Hãy nhập từ khóa hẹp hơn để tìm tiếp."
                textSize = 11f
                setTextColor(Color.rgb(157, 165, 187))
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            objectsPanel.addView(note)
        }
    }

    private fun showObjectMenu(item: JSONObject) {
        val pid = item.optLong("path_id")
        val type = item.optString("type")
        val choices = mutableListOf("Xem TypeTree", "Truy vết PPtr", "Chỉnh field số", "Xuất dữ liệu thô")
        if (type == "Texture2D" || type == "Sprite") choices.add("Preview / xuất PNG")
        if (type == "Mesh") choices.add("Xuất Mesh OBJ")
        AlertDialog.Builder(this)
            .setTitle(item.optString("name").ifBlank { "$type · $pid" })
            .setItems(choices.toTypedArray()) { _, which ->
                when (choices[which]) {
                    "Xem TypeTree" -> inspectObject(pid)
                    "Truy vết PPtr" -> inspectReferences(pid)
                    "Chỉnh field số" -> editField(pid, type)
                    "Xuất dữ liệu thô" -> exportRaw(pid)
                    "Preview / xuất PNG" -> previewTexture(pid)
                    "Xuất Mesh OBJ" -> exportMesh(pid)
                }
            }.show()
    }

    private fun inspectObject(pathId: Long) {
        val file = bundleFile ?: return
        setStatus("Đang đọc TypeTree của $pathId…")
        io.execute {
            try {
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("inspect_object", file.absolutePath, pathId).toString())
                runOnUiThread {
                    if (!result.optBoolean("ok")) {
                        showLong("Không đọc được TypeTree", result.optString("traceback", result.optString("error")))
                    } else {
                        val body = "Type: ${result.optString("type")}\nPathID: $pathId\n\n${result.optString("tree")}"
                        showLong("Object $pathId", body)
                    }
                    setStatus("Đã hoàn tất đọc object $pathId.")
                }
            } catch (e: Exception) { runOnUiThread { showLong("Lỗi", e.stackTraceToString()) } }
        }
    }

    private fun inspectReferences(pathId: Long) {
        val file = bundleFile ?: return
        setStatus("Đang truy vết PPtr của $pathId…")
        io.execute {
            try {
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("object_references", file.absolutePath, pathId).toString())
                runOnUiThread {
                    if (result.optBoolean("ok")) showLong("${result.optInt("reference_count")} tham chiếu · $pathId", result.optJSONArray("references")?.toString(2) ?: "[]")
                    else showLong("Lỗi truy vết", result.optString("traceback", result.optString("error")))
                }
            } catch (e: Exception) { runOnUiThread { showLong("Lỗi truy vết", e.stackTraceToString()) } }
        }
    }

    private fun exportMesh(pathId: Long) {
        val input = bundleFile ?: return
        setStatus("Đang xuất Mesh $pathId thành OBJ…")
        io.execute {
            try {
                val out = File(filesDir, "exports/mesh_$pathId.obj").apply { parentFile?.mkdirs() }
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("export_mesh_obj", input.absolutePath, pathId, out.absolutePath).toString())
                runOnUiThread {
                    if (result.optBoolean("ok")) { pendingOutput = out; pendingMime = "text/plain"; createDocument.launch(out.name) }
                    else showLong("Xuất Mesh thất bại", result.optString("traceback", result.optString("error")))
                }
            } catch (e: Exception) { runOnUiThread { showLong("Lỗi xuất Mesh", e.stackTraceToString()) } }
        }
    }

    private fun editField(pathId: Long, type: String) {
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val pathInput = EditText(this).apply { hint = "Property path, ví dụ: m_SavedProperties.m_Floats._Cutoff"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val valueInput = EditText(this).apply { hint = "Giá trị mới (số)"; inputType = 8194; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        content.addView(pathInput)
        content.addView(valueInput)
        AlertDialog.Builder(this).setTitle("Chỉnh field số · $type")
            .setMessage("Chỉ sửa field số đã tồn tại trong TypeTree. Bản gốc sẽ không bị ghi đè.")
            .setView(content)
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Sửa và xuất") { _, _ ->
                val propertyPath = pathInput.text.toString().trim()
                val newValue = valueInput.text.toString().trim()
                if (propertyPath.isBlank() || newValue.isBlank()) {
                    setStatus("Cần nhập đủ property path và giá trị mới.")
                } else runEdit(pathId, propertyPath, newValue)
            }.show()
    }

    private fun runEdit(pathId: Long, propertyPath: String, newValue: String) {
        val input = bundleFile ?: return
        setStatus("Đang áp dụng chỉnh sửa và ghi bundle mới…")
        io.execute {
            try {
                val outDir = File(filesDir, "exports").apply { mkdirs() }
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("edit_numeric_property", input.absolutePath,
                    pathId, propertyPath, newValue, outDir.absolutePath).toString())
                runOnUiThread {
                    if (result.optBoolean("ok")) {
                        val out = File(result.getString("output"))
                        pendingOutput = out
                        pendingMime = "application/octet-stream"
                        setStatus("Đã ghi và xác minh field. Chọn nơi lưu bundle mới.")
                        createDocument.launch(out.name.replace(".assetbundle", "_edited.assetbundle"))
                    } else {
                        setStatus("Chỉnh sửa thất bại: ${result.optString("error")}")
                        showLong("Không thể sửa field", result.optString("traceback", result.optString("error")))
                    }
                }
            } catch (e: Exception) { runOnUiThread { setStatus("Lỗi: ${e.message}"); showLong("Lỗi chỉnh sửa", e.stackTraceToString()) } }
        }
    }

    private fun previewTexture(pathId: Long) {
        val input = bundleFile ?: return
        setStatus("Đang giải mã texture $pathId…")
        io.execute {
            try {
                val out = File(cacheDir, "preview/texture_$pathId.png").apply { parentFile?.mkdirs() }
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("export_texture", input.absolutePath, pathId, out.absolutePath).toString())
                runOnUiThread {
                    if (!result.optBoolean("ok")) {
                        setStatus("Không preview được texture: ${result.optString("error")}")
                        showLong("Texture decoder", result.optString("traceback", result.optString("error")))
                    } else {
                        val image = ImageView(this).apply {
                            setImageBitmap(BitmapFactory.decodeFile(out.absolutePath))
                            adjustViewBounds = true
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setBackgroundColor(Color.rgb(40, 42, 55))
                        }
                        val wrap = ScrollView(this).apply { addView(image) }
                        AlertDialog.Builder(this).setTitle("${result.optInt("width")} × ${result.optInt("height")} · PNG")
                            .setView(wrap).setPositiveButton("Xuất PNG") { _, _ ->
                                pendingOutput = out; pendingMime = "image/png"
                                createDocument.launch("texture_${pathId}.png")
                            }.setNegativeButton("Đóng", null).show()
                        setStatus("Texture đã giải mã thành PNG.")
                    }
                }
            } catch (e: Exception) { runOnUiThread { showLong("Lỗi preview", e.stackTraceToString()) } }
        }
    }

    private fun exportRaw(pathId: Long) {
        val input = bundleFile ?: return
        setStatus("Đang xuất raw object $pathId…")
        io.execute {
            try {
                val out = File(filesDir, "exports/object_$pathId.dat")
                out.parentFile?.mkdirs()
                val py = Python.getInstance().getModule("aov_android_backend")
                val result = JSONObject(py.callAttr("export_raw", input.absolutePath, pathId, out.absolutePath).toString())
                runOnUiThread {
                    if (result.optBoolean("ok")) {
                        pendingOutput = out; pendingMime = "application/octet-stream"
                        createDocument.launch(out.name)
                    } else showLong("Xuất raw thất bại", result.optString("error"))
                }
            } catch (e: Exception) { runOnUiThread { showLong("Lỗi xuất raw", e.stackTraceToString()) } }
        }
    }

    private fun exportPending(uri: Uri) {
        val file = pendingOutput ?: return
        io.execute {
            try {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "Không tạo được file đích" }
                    file.inputStream().use { input -> input.copyTo(output, 1024 * 1024) }
                }
                runOnUiThread { setStatus("Đã lưu: ${file.name}") }
            } catch (e: Exception) { runOnUiThread { setStatus("Lỗi xuất file: ${e.message}") } }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "input.assetbundle"
        }
        return "input.assetbundle"
    }

    private fun showLong(title: String, message: String) {
        val tv = TextView(this).apply { text = message; textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(18), dp(10), dp(18), dp(10)) }
        AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(tv) }).setPositiveButton("Đóng", null).show()
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = rounded(Color.rgb(99, 83, 214), 12)
        setOnClickListener { action() }
    }
    private fun setStatus(value: String) { if (::status.isInitialized) status.text = value }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchParams(bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (bottom > 0) bottomMargin = dp(bottom) }
    private fun marginParams(bottom: Int = 0) = matchParams(bottom)
    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
